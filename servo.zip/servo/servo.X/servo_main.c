#include <xc.h>
#include "config.h"
#include "i2c.h"

#define _XTAL_FREQ 40000000

#define TIM0_INTERVAL_MS 0.0256
#define FOR1S 26472
#define FOR20MS 64753
#define SERVO_0 40 // 57 times for 1.45ms

char addr = 0;

char recv_i2c = 0;

void interrupt intr();
void init();
unsigned getTim0();

void main(void) {
    init();
    unsigned tmr0 = 0;
    signed char servo[4];
    while(1){
        for(int i = 0; i < 4; i++){
            servo[i] = 40;
        }
        if(recv_i2c & 0b1)
            servo[0] = 0;
        if(recv_i2c & 0b10)
            servo[1] = 0;
        
//        if(recv_i2c & 0b100)
//            servo[2] = 0;
//        if(recv_i2c & 0b1000)
//            servo[3] = 0;
        
        tmr0 = getTim0();
        if(tmr0 == (FOR20MS + SERVO_0 + servo[0])){ // -28 to 0 to 28
            LATDbits.LD7 = 0;
        }
        if(tmr0 == (FOR20MS + SERVO_0 + servo[1])){ // -28 to 0 to 28
            LATDbits.LD6 = 0;
        }
//        if(tmr0 == (FOR20MS + SERVO_0 + servo[2])){ // -28 to 0 to 28
//            LATDbits.LD5 = 0;
//        }
//        if(tmr0 == (FOR20MS + SERVO_0 + servo[3])){ // -28 to 0 to 28
//            LATDbits.LD4 = 0;
//        }
    }
    return;
}

void interrupt intr(){
    if(PIR1bits.SSPIF){
        if ( PIR1bits.SSPIF ){
            if ( SSPSTATbits.BF ){
                char tmp = SSPBUF;
                if ( SSPSTATbits.D_A ){
                    recv_i2c = tmp;
                }
            }
            SSPCON1bits.CKP = 1;
        }
        LATA = recv_i2c;
        PIR1bits.SSPIF = 0;
    }
    if(INTCONbits.T0IF){
        LATD = 0b11110000;
        TMR0H = FOR20MS >> 8;
        TMR0L = FOR20MS & 0xFF;
        INTCONbits.T0IF = 0;
    }
}

void init(){
    TRISA  = TRISB	= TRISC	= TRISD	= TRISE	= 0;
	LATA   = LATB	= LATC	= LATD	= LATE	= 0;
    
    // MTR0 
    T0CONbits.T0CS = 0;
    T0CONbits.T08BIT = 0;
    T0CONbits.PSA = 0;
    T0CONbits.T0PS = 0b111;
    INTCONbits.T0IF = 0;
    INTCONbits.T0IE = 1;
    
    // i2c
    addr = read_addr();
    i2cInit();
    
	INTCONbits.PEIE	= 1;
	INTCONbits.GIE 	= 1;
    
    T0CONbits.TMR0ON = 1;
}

unsigned getTim0(){
    unsigned t = TMR0L;
    t += TMR0H << 8;
    return t;
}
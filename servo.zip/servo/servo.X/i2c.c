#include <xc.h>
#include "i2c.h"

char I2C_SLAVE_ADDRESS = 0x10;

char read_addr(){
    ADCON1 = 0b1111;
    TRISBbits.RB5 = 1;
    TRISBbits.RB4 = 1;
    TRISBbits.RB3 = 1;
    TRISBbits.RB2 = 1;
    
    I2C_SLAVE_ADDRESS = 0x10 + ((PORTB & 0b111100)>>1);
    SSPADD	= I2C_SLAVE_ADDRESS;
    
    return I2C_SLAVE_ADDRESS;
}

char i2cIntrHandler(){
    char gReceiveI2C = 0;
	if ( PIR1bits.SSPIF ){
		if ( SSPSTATbits.BF ){
			char tmp = SSPBUF;
			if ( SSPSTATbits.D_A ){
				gReceiveI2C = tmp;
			}
		}
		SSPCON1bits.CKP = 1;
	}
	PIR1bits.SSPIF = 0;
    return gReceiveI2C;
}

void i2cInit(){
	TRISC	= 0b00011000;
	
	// I2C??
	//	?400kbps
	//	?SDA?SCL?????????
	//	?????
	//	?7???????
	SSPSTAT	= 0b00100000;
	SSPCON1	= 0b00110110;
	SSPCON2	= 0b01001000;
	SSPADD	= I2C_SLAVE_ADDRESS;
	
	// ??????
	RCONbits.IPEN 	= 0;	// ????????
	IPR1bits.SSPIP	= 1;	// MSSP???????
    PIE1bits.SSPIE 	= 1;
}

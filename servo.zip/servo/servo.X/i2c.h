#ifndef H_I2C_SLAVE_INCLUDED
#define H_I2C_SLAVE_INCLUDED

char read_addr();

char i2cIntrHandler();

void i2cInit();

#endif
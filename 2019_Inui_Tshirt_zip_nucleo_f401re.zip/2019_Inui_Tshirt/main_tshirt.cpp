#include "includes.h"

#define KP 0.55
#define KI 0.05
#define KD 0.04

#define KP2 0.08
#define KI2 0.011
#define KD2 0.0

#define KP3 0.15
#define KI3 0.02
#define KD3 0.0

////////////////////

#define KP22 0.1
#define KI22 0.02
#define KD22 0.0

#define KP23 0.1
#define KI23 0.02
#define KD23 0.0

////////////////////

#define LED_ADDRESS 0x20

#define P_HEADER 0xA6
#define S_HEADER 0xB6

#define TORIKOMI 1
#define HAKIDASHI 2
#define SHOKI 3
#define SERVO 4

#define BLUE_FIELD 0
#define RED_FIELD 1

#define GOTOFLAG 1

DigitalOut myled1(PC_8);
DigitalOut myled2(PC_6);
DigitalOut myled3(PC_5);
DigitalIn sw(PC_4);
DigitalIn button(PB_12);
I2C i2c(PB_7,PB_8);
Serial pc(USBTX,USBRX);

PID pid(KP, KI, KD);
PID pidx(KP2, KI2, KD2);
PID pidy(KP3, KI3, KD3);

PID pidx2(KP2, KI2, KD2);
PID pidy2(KP3, KI3, KD3);

Serial serial(PB_6,PA_10);
Serial gyro(PA_11,PA_12);

OLED oled(&i2c);
OMNI omni(&i2c, &pid, &oled);

char R6093U_data[24];
float R6093U_before = 0;
float R6093U_act_before = 0;
float R6093U_get(char data_arr[], char sel);

void gyro_handler(){
    if(gyro.getc() == 0xA6){
        if(gyro.getc() == 0xA6){
            for(int cnt = 0; cnt < 7; cnt++){
                R6093U_data[cnt] = gyro.getc();
            }
        }
        else{
            return;
        }
    }
    else{
        return;
    }
}

char pc_data[6];
char pc_data_buckup[6];
char pc_cnt = 0;
char phase = 0;
char subphase = 0;
char my_phase = 0;
char my_subphase = 0;
signed short distance_x = 0;
signed short distance_y = 0;
char field_color = 0;
char field_mode = 0;
char towel = 0;
char aaa = 0;

void pc_handler(){
    for(int i = 0; i < 6; i++){
        pc_data_buckup[i] = pc_data[i];
    }
    pc_data[0] = pc.getc();
    if(pc_data[0] >= 0x80){
        for(int cnt = 1; cnt < 6; cnt++){
            pc_data[cnt] = pc.getc();
            if(pc_data[cnt] >= 128){
                for(int j = 0; j < 6; j++){
                    pc_data[j] = pc_data_buckup[j];
                }
                break;
            }
        }
    }
    else{
        for(int j = 0; j < 6; j++){
            pc_data[j] = pc_data_buckup[j];
        }
    }
    
    field_color = (pc_data[0] & 0x10) > 0;
    field_mode = (pc_data[0] & 0x08) > 0;
    towel = (pc_data[0] & 0x04) > 0;
    phase = (char)((((short)pc_data[0] & 0x03) << 3) | (((short)pc_data[1] & 0x70) >> 4));
    distance_x = (short)(((pc_data[1] & 0x0C) << 12) + (pc_data[2] << 7) + pc_data[3]);
    distance_y = (short)(((pc_data[1] & 0x03) << 14) + (pc_data[4] << 7) + pc_data[5]);
    
    // 100cmtpp 0pppxxyy 0xxxxxxx 0xxxxxxx 0yyyyyyy 0yyyyyyy  (to send 2bytes + header, p:phase, x:distance_x, y:distance_y)
    return;
}

char uart_recv_data = 0;
char uart_num_tx = 0;
char uart_cnt;
char uart_address = 0x04; 
char uart_send_data[4] = {0};

void uart_receiving() {
    char buf;
    buf = serial.getc();
    
    if(buf == 0xA6) {
        if(serial.getc() == 0xB6) {
            buf = serial.getc();
        }
        else 
            return;
    }
    else 
        return;
    uart_recv_data = buf;
}

void uart_sending(char address, char data){
    uart_num_tx  = data; 
    uart_address = address;
    if(uart_address > 0x0F){
        uart_address = 0;                      
    }    
    uart_send_data[0] = P_HEADER;          
    uart_send_data[1] = S_HEADER;          
    uart_send_data[2] = uart_address;          //address
    uart_send_data[3] = uart_num_tx;           //data of tx
    for(uart_cnt = 0; uart_cnt <= 3; uart_cnt++)
        serial.putc(uart_send_data[uart_cnt]);
}

int main(){
    gyro.baud(38400);
    pc.baud(19200);
    serial.baud(38400);

    oled.OLED_init();
    rotary_encoder_ab_phase e(TIM2, 24);
    e.start();
    
    gyro.printf("$MIB,RESET*87");
    wait(0.7);
    gyro.attach(gyro_handler, Serial::RxIrq);
    pc.attach(pc_handler, Serial::RxIrq);
    serial.attach(uart_receiving, Serial::RxIrq);
            
    char d = 0;
    float z = 0;
    
    myled1 = 0;
    myled2 = 0;
    myled3 = 0;
    
    float pid_y = 0;
    float pid_x = 0;
    float angle = 0;
    int degree = 0;
    
    char moji[16] = {0};

    int speed_cnt = 0;
    int speed_max = 0;
    int speed_min = 0;
    bool subphase_flag = false;
    bool torikomi_flag = false;    

    int phase2_cnt = 50;
    int phase3_cnt = 0;
    int phase4_cnt = 0;
    int phase5_cnt = 0;
    int phase6_cnt = 0;
    char my_y = 0;
    float power = 0;
    char roller = 0;
    
    sprintf(moji, "STAND BY...");
    oled.OLED_printf(moji, 0);
//    while(1){
//        for(int i = 1; i < 7; i++){
//            uart_sending(0x01, i);
//            sprintf(moji, "gp:%d g:%d", i, uart_recv_data);
//            oled.OLED_printf(moji, 4);
//            while(!sw || !button);
//            wait(0.5);
//            uart_recv_data = 0;
//        }
//    }
    int gp = 1;
    while(!sw){
        if(button){
            uart_recv_data = 0;
            uart_sending(0x01, gp);
            wait(0.5);
            sprintf(moji, "gp:%d get:%d", gp, uart_recv_data);
            oled.OLED_printf(moji, 4);
            gp++;
            if(gp > 2){
                gp = 1;
            }
        }
        sprintf(moji, "gp:%d get:%d", gp, uart_recv_data);
        oled.OLED_printf(moji, 4);
        my_y = (signed char)50;
        i2c.write(LED_ADDRESS, &my_y, 1, 0);
//        roller = abs(distance_y) & 0x3F + 0x00 + 0;
//        uart_sending(0x04, roller);
//        roller = ((abs(distance_y) >> 6) & 0x3F) + 0x80 + 0;
//        uart_sending(0x04, roller);
//        roller = abs(distance_x) & 0x3F + 0x00 + 0x40;
//        uart_sending(0x04, roller);
//        roller = ((abs(distance_x) >> 6) & 0x3F) + 0x80 + 0x40;
//        uart_sending(0x04, roller);

        z = R6093U_get(R6093U_data, 'Z');
        sprintf(moji, "%7.2f", z);
        oled.OLED_printf(moji, 1);
        sprintf(moji, "p:%d", phase);
        oled.OLED_printf(moji, 2);
        sprintf(moji, "x:%5d y:%5d", abs(distance_y), abs(distance_x));
        oled.OLED_printf(moji, 3);

        if(field_color == BLUE_FIELD){
            omni.omni(0, 0, 0, z, 0);
        }
        else{
            omni.omni_b2r(0, 0, 0, z, 0);
        }
    }
    
    sprintf(moji, "PLAY NOW");
    oled.OLED_printf(moji, 0);   
    
    while(1)
    {
        my_y = (signed char)50;
        i2c.write(LED_ADDRESS, &my_y, 1, 0);
        z = R6093U_get(R6093U_data, 'Z');
        
        switch(phase){
            case 0:{ // start zone 2
                degree = 0;
                pid_y = -pidy.get_pid(distance_y, 62);
                pid_x = -pidx.get_pid(distance_x, 62);
                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI;
                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                if(power < 6 && power > 0.8) power = 6;
                if(field_color == BLUE_FIELD){
                    omni.omni(angle, (int)power, 0, z, degree);
                }
                else{
                    omni.omni_b2r(angle, (int)power, 0, z, degree);
                }
            } break;
            case 1:{ // go to zone t
                if(my_phase != 1){
                    degree = 0;
                    speed_max = 900;
                    speed_min = 0;
                    speed_cnt = speed_min;
                }
                if(distance_y > 120){
                    pid_y = pidy.get_pid(distance_y, 115);
                    pid_x = -pidx.get_pid(distance_x, 55);
                    angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI;
                    power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                    if(power < 12 && power > 1) power = 12;
                    if(field_color == BLUE_FIELD){
                        omni.omni(angle, (int)power, 0, z, degree);
                    }
                    else{
                        omni.omni_b2r(angle, (int)power, 0, z, degree);
                    }
                    if(speed_cnt < speed_max)
                        speed_cnt++;
                }
                else{
                    pid_y = pidy.get_pid(distance_y, 40);
                    pid_x = -pidx.get_pid(distance_x, 50);
                    angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI;
                    power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                    if(power < 7 && power > 1) power = 7;
                    if(field_color == BLUE_FIELD){
                        omni.omni(angle, (int)power, 0, z, degree);
                    }
                    else{
                        omni.omni_b2r(angle, (int)power, 0, z, degree);
                    }
                }
                my_phase = 1;
            } break;
            case 2:{ // help zone
                if(my_phase != 2){
                    speed_max = 600;
                    speed_min = 50;
                    speed_cnt = speed_min;
                    degree = -180;
                    for(int p = 0; p < 600; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(field_color == BLUE_FIELD){
                            omni.omni(0, 8, 0, z, 0);
                        }
                        else{
                            omni.omni_b2r(0, 8, 0, z, 0);
                        }
                    }
                    int p = 1;
                    if(GOTOFLAG){
                        uart_recv_data = 0;
                        uart_sending(0x01, TORIKOMI);
                        while(!uart_recv_data);
                    }
                    for(int p = 0; p < 500; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(field_color == BLUE_FIELD){
                            omni.omni(180, 8, 0, z, 0);
                        }
                        else{
                            omni.omni_b2r(180, 8, 0, z, 0);
                        }
                    }
                }
                if(z > 0){
                    z = -360+z;
                }
                if(z < -200 || z > -80){
                    if(field_color == BLUE_FIELD){
                        omni.omni(170, 17, 17, (int)z, (int)z);
                    }
                    else{
                        omni.omni_b2r(170, 17, 17, (int)z, (int)z);
                    }
                }
                else{
                    if(distance_y > 100){
                        pid_y = pidy.get_pid(distance_y, 80);
                        pid_x = pidx.get_pid(distance_x, 60);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 180;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                        if(power < 6 && power > 1) power = 6;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                    }
                    else{
                        pid_y = pidy.get_pid(distance_y, 40);
                        pid_x = pidx.get_pid(distance_x, 60);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 180;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power < 9 && power > 1) power = 9;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);    
                        }
                    }
                }
                my_phase = 2;
            } break;
            case 3:{
                if(my_phase == 4){
                    while(1){
                        if(sw) break;
                    }
                    for(int p = 0; p < 300; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(z > 0){
                            z = -360+z;
                        }
                        if(field_color == BLUE_FIELD){
                            omni.omni(0, 8, 0, z, -180);
                        }
                        else{
                            omni.omni_b2r(0, 8, 0, z, -180);
                        }
                    }
                    degree = -270;
                }
                else if(my_phase != 3){
                    speed_max = 1000;
                    speed_min = 0;
                    speed_cnt = speed_min;
                    subphase = 0;
                    subphase_flag = 0;
                    for(int p = 0; p < 300; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(z > 0){
                            z = -360+z;
                        }
                        if(field_color == BLUE_FIELD){
                            omni.omni(180, 6, 0, z, -180);
                        }
                        else{
                            omni.omni_b2r(180, 6, 0, z, -180);
                        }
                    }
                    int p = 2;
                    if(GOTOFLAG){
                        uart_recv_data = 0;
                        uart_sending(0x01, HAKIDASHI);
                        while(!uart_recv_data);
                        uart_sending(0x01, SHOKI);
                        while(!uart_recv_data);
                    }
                    while(1){
                        if(sw) break;
                    }
                    for(int p = 0; p < 300; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(z > 0){
                            z = -360+z;
                        }
                        if(field_color == BLUE_FIELD){
                            omni.omni(0, 8, 0, z, -180);
                        }
                        else{
                            omni.omni_b2r(0, 8, 0, z, -180);
                        }
                    }
                    degree = -270;
                }
                if(z > 0){
                    z = -360+z;
                }
                if(z > -260){
                    if(field_color == BLUE_FIELD){
                        omni.omni(75, 20, -20, (int)z, (int)z);
                    }
                    else{
                        omni.omni_b2r(75, 20, -20, (int)z, (int)z);
                    }
                }
                else{
                    if(distance_x < 350 || distance_y > 295){
                        pid_x = -pidx2.get_pid(distance_y, 285) * 1.5f;
                        pid_y = -pidy2.get_pid(distance_x, 365);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                        if(power < 10 && power > 1) power = 10;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max){
                            speed_cnt++;
                        }
                    }
                    else{
                        if(subphase_flag == false){
                            speed_max = 800;
                            speed_min = 50;
                            speed_cnt = speed_min;
                        }
                        subphase_flag = true;
                        pid_x = -pidx2.get_pid(distance_y, 285);
                        pid_y = -pidy2.get_pid(distance_x, 409);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                        if(power < 10) power = 10;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < (speed_max-80)){
                            speed_cnt++;
                        }
                    }
                }
                my_phase = 3;
            } break;
            case 4:{
                if(my_phase != 4){
                    speed_max = 800;
                    speed_min = 30;
                    speed_cnt = speed_min;
                    subphase = 0;
                    subphase_flag = 0;
                    degree = -90;
                    for(int p = 0; p < 450; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(z > 0){
                            z = -360+z;
                        }
                        if(field_color == BLUE_FIELD){
                            omni.omni(-90, 17, 0, z, -270);
                        }
                        else{
                            omni.omni_b2r(-90, 17, 0, z, -270);
                        }
                    }
                }
                if(z > 0){
                    z = -360+z;
                }
                if(z < -100){
                    if(field_color == BLUE_FIELD){
                        omni.omni(0, 10, 23, (int)z, (int)z);
                    }
                    else{
                        omni.omni_b2r(0, 10, 23, (int)z, (int)z);
                    }
                }
                else{
                    if(subphase_flag == 0){
                        if(distance_y > 206){
                            subphase_flag = 0;
                            pid_x = pidx2.get_pid(distance_y, 205)*1.1f;
                            pid_y = pidy2.get_pid(distance_x, 355);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 10 && power > 1) power = 10;
                            if(field_color == BLUE_FIELD){
                                omni.omni(0, 17, 0, (int)z, (int)z);
                            }
                            else{
                                omni.omni_b2r(0, 17, 0, (int)z, (int)z);
                            }
                        }
                        else{
                            pid_x = pidx2.get_pid(distance_y, 205)*1.3f;
                            pid_y = pidy2.get_pid(distance_x, 455);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 10) power = 10;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(distance_x > 450 && distance_y < 209){
                                subphase_flag = 1;
                            }
                        }
                    }
                    else{
                        if(distance_x > 380){
                            pid_x = pidx2.get_pid(distance_y, 205);
                            pid_y = pidy2.get_pid(distance_x, 350);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 10 && power > 1) power = 10;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 200)){
                                speed_cnt++;
                            }
                            subphase = 1;
                        }
                        else{
                            if(subphase == 1){
                                speed_cnt = speed_min;
                                subphase = 0;
                            }
                            pid_x = pidx2.get_pid(distance_y, 380);
                            pid_y = pidy2.get_pid(distance_x, 55);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 12 && power > 2) power = 12;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 100)){
                                speed_cnt++;
                            }
                        }
                    }
                }
                my_phase = 4;
            } break;
            case 5:{
                if(my_phase != 5){
                    speed_max = 900;
                    speed_min = 0;
                    speed_cnt = speed_min;
                    subphase = 0;
                    while(!sw);
                    gyro.printf("$MIB,RESET*87");
                    gyro.printf("$MIB,RESET*87");
                    wait(0.5);
                    gyro.printf("$MIB,RESET*87");
                    gyro.printf("$MIB,RESET*87");
                    wait(0.7);
                }
                degree = 0;
                switch(subphase){
                    case 0:{
                        while(distance_y > 255){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 245);
                            pid_y = -pidy.get_pid(distance_x, 60);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 2) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 40))
                                speed_cnt++;
                        }
                        speed_cnt = 0;
                        
                        for(int l = 0; l < 140; l++){
                            z = R6093U_get(R6093U_data, 'Z');
                            roller = l & 0x3F + 0x00 + 0;
                            uart_sending(0x04, roller);
                            roller = ((l >> 6) & 0x3F) + 0x80 + 0;
                            uart_sending(0x04, roller);
                            roller = l & 0x3F + 0x00 + 0x40;
                            uart_sending(0x04, roller);
                            roller = ((l >> 6) & 0x3F) + 0x80 + 0x40;
                            uart_sending(0x04, roller);
                            if(field_color == BLUE_FIELD){
                                omni.omni(0, 0, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(0, 0, 0, z, degree);
                            }
                            for(int i = 0; i < 100; i++);
                        }
                        
                        while(distance_y < 395){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 410);
                            pid_y = -pidy.get_pid(distance_x, 60);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 2) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max))
                                speed_cnt++;
                        }
                        while(!sw);
                        subphase = 1;
                        speed_cnt = 0;
                    } break;
                    case 1:{
                        while(distance_x < 260){
                            int p = 2;
                            serial.putc(p);
                            while(!uart_recv_data);
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 380);
                            pid_y = -pidy.get_pid(distance_x, 310);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < speed_max)
                                speed_cnt++;
                        }
                        speed_cnt = 300;
                        while(distance_y < 470){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 500);
                            pid_y = -pidy.get_pid(distance_x, 400);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 100))
                                speed_cnt++;
                        }
                        speed_cnt = 100;
                        while(distance_x < 545){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 500);
                            pid_y = -pidy.get_pid(distance_x, 550);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 100))
                                speed_cnt++;
                        }
                        speed_cnt = 30;
                        subphase = 2;
                        my_subphase = 1;
                    } break;
                    case 2:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 320);
                        pid_y = -pidy.get_pid(distance_x, 550);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 2){
                            subphase = 3;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 2;
                    } break;
                    case 3:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 320);
                        pid_y = -pidy.get_pid(distance_x, 645);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 2){
                            subphase = 4;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 3;
                    } break;
                    case 4:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 345);
                        pid_y = -pidy.get_pid(distance_x, 645);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(distance_y > 340){
                            subphase = 5;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 4;
                    } break;
                    case 5:{
                        for(int p = 0; p < 200; p++){
                            z = R6093U_get(R6093U_data, 'Z');
                            angle = 90 - 90;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, 9, 0, z, 0);
                            }
                            else{
                                omni.omni_b2r(angle, 9, 0, z, 0);
                            }
                        }
                        
                        while(distance_y > 150){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -10;
                            pid_y = -pidy.get_pid(distance_x, 645)*1.5f;
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                        }
                        
                        for(int p = 0; p < 200; p++){
                            z = R6093U_get(R6093U_data, 'Z');
                            angle = -90 - 90;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, 9, 0, z, 0);
                            }
                            else{
                                omni.omni_b2r(angle, 9, 0, z, 0);
                            }
                        }
                        subphase = 6;
                        my_subphase = 5;
                    } break;
                    case 6:{
                        if(my_subphase != 6){
                            speed_cnt = 0;
                            while(distance_x > 570){
                                z = R6093U_get(R6093U_data, 'Z');
                                pid_x = -pidx.get_pid(distance_y, 160);
                                pid_y = -pidy.get_pid(distance_x, 555);
                                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                                if(power < 10 && power > 1) power = 10;
                                power = power*speed_cnt/speed_max;
                                if(speed_cnt < speed_max)
                                    speed_cnt++;
                                if(field_color == BLUE_FIELD){
                                    omni.omni(angle, power, 0, z, degree);
                                }
                                else{
                                    omni.omni_b2r(angle, power, 0, z, degree);
                                }
                            }
                            speed_cnt = 0;
                        }
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 500);
                        pid_y = -pidy.get_pid(distance_x, 580) * 1.3f;
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 3){
                            subphase = 7;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max - 100)
                            speed_cnt++;
                        my_subphase = 6;
                    } break;
                    case 7:{
                        speed_cnt = 10;
                        while(distance_x > 370){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 500);
                            pid_y = -pidy.get_pid(distance_x, 360);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 100))
                                speed_cnt++;
                        }
                        speed_cnt = 200;
                        while(distance_y > 360){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -17;
                            pid_y = -18;
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 200))
                                speed_cnt++;
                        }
                        speed_cnt = 5;
                        while(distance_x > 60){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 350);
                            pid_y = -pidy.get_pid(distance_x, 60);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < speed_max)
                                speed_cnt++;
                        }
                        speed_cnt = 0;
                        phase = 6;
                        my_subphase = 7;
                    } break;
                    default: break;
                }
                my_phase = 5;
            } break;
            case 6:{
                subphase = 0;
                my_subphase = 0;                
                phase = 5;
                my_phase = 6;
            } break;
            case 7:{
                my_phase = 7;
            } break;
            case 8:{
                my_phase = 8;
            } break;
            case 9:{
                my_phase = 9;
            } break;
            default :break;
        }
        
        if(sw){
            myled1 = 1;
            myled2 = !button;
            myled3 = !sw;
        }
        else{
            myled1 = 0;
            myled2 = 0;
            myled3 = 0;
        }
        
//        d = e.get_counts();
//        oled.OLED_bar(0, 7, (char)d);
//        oled.OLED_line_clear(7, (char)d);
//        sprintf(moji, "x:%5d y:%5d", (int)distance_x, (int)distance_y);
//        oled.OLED_printf(moji, 3);
//        sprintf(moji, "p:%d", phase);
//        oled.OLED_printf(moji, 2);
//        sprintf(moji, "%7.2f", z);
//        oled.OLED_printf(moji, 1);
    }
}

float R6093U_get(char data_arr[], char sel) {
    signed short angle = 0;
    float ang = 0;
    
    switch(sel){
        case 'X': angle = data_arr[1] | (data_arr[2]<<8); break;
        case 'Y': angle = data_arr[3] | (data_arr[4]<<8); break;
        case 'Z': angle = data_arr[5] | (data_arr[6]<<8); break;
        default : angle = 0; break;
    }
    
    ang = angle * (float)0.01;
    if((abs(ang)-abs(R6093U_act_before)) > 30){
        R6093U_act_before = ang;
        ang = R6093U_before;
    }
    else{
        R6093U_act_before = ang;
    }
    R6093U_before = ang;
    
    if(field_color == RED_FIELD){
        return -ang;
    }
    else{
        return ang;
    }
    
}
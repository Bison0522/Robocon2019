#pragma once

class PID
{
private:
    float Kp;
    float Ki;
    float Kd;
    float En;
    float En_1;
    float En_2;
    float b;
    float integ;

public:
    PID(float, float, float);

    float get_pid(float, float);

    ~PID();
};
#include "PID.h"

PID::PID( float p, float i, float d ) {
    Kp = p;
    Ki = i;
    Kd = d;
    integ = 0;
    En_1 = 0;
    En_2 = 0;
}

float PID::get_pid(float target, float now) {
    En = target - now;
    integ = Ki * En_2 + Ki * En_2 + Ki * En;
    b = integ + Kp * En + Kd * ((En - En_1) - (En_1 - En_2));
    En_2 = En_1;
    En_1 = En;
    if(b > 127){
        b = 127;
    }
    else if(b < -127){
        b = -127;
    }
    return b;
}

PID::~PID() {

}
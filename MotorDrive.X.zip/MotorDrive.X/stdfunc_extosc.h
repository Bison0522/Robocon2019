#ifndef STDFUNC_EX_H
#define STDFUNC_EX_H

#include <xc.h>

#define _XTAL_FREQ 48000000
#define EESIZE 256
#define TIMEOUT 2000
#define DEADHAND 5

#define LIMIT_10K 94
#define LIMIT_30K 94
#define LIMIT_50K 94
#define LIMIT_75K 94
#define LIMIT_22K 127

#define FULL 132

void intr_init();
void disa_intr();
void init();
void md_init(char active);

void EE_init();
unsigned char EE_read(int adrs);
void EE_write(int adrs, unsigned char data);
void EE_clear();

void ADC_init();
char ADC_read();

void i2c_init(char select);
char which_am_i();
/* !CAUTION! */
// addr is slave address contains RW(set 0)bit. 8bit
char i2c_write(int addr, char *data, char num);
char i2c_read(int addr, char *data, char num);
void set_addr(char addr);
char set_md_addr();

void serial_init();
void serial_baud(unsigned long baud);
void serial_write(char *data, char num);

void full_bridge_pwm_init(char frequency);
void restart_pwm_full();
void fin_pwm_full();
void brake_full();
void change_rotate_full(char s);
void set_duty_full(char duty, char rotate);

void fin_pwm_half();
void restart_pwm_half();
void brake_half();
void free_half();
void change_rotate_half(char r);
void set_deadhand();
void half_bridge_pwm_init(char frequency);
void set_duty_half(unsigned char duty);

#endif
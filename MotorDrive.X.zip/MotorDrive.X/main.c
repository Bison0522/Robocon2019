#include <xc.h>
#include "config.h"
#include "stdfunc_extosc.h"

/* !CAUTION! */
// i2c_write/read() : addr is slave address without RWbit. 7bit
// set_addr() : addr is slave address without RWbit. 7bit

#define IIC_TIMEOUT 200000
#define _XTAL_FREQ 48000000 // internal 48MHz
#define I2C_ARRAY_LENGTH 32

typedef signed char _uint8;
typedef unsigned long _uint32;

_uint8 data_i2c[I2C_ARRAY_LENGTH] = {0};
_uint8 data_serial = 0;
_uint8 i2c_data_cnt = 0;
_uint8 rotate = 0;
_uint8 free_flag = 0;

_uint32 time_out = 0;

void interrupt intr(){
    // EEPROM
    if(PIR2bits.EEIF){
        // writing ended
        PIR2bits.EEIF = 0;
    }
    
    // ADC
    if(PIR1bits.ADIF){
        // ADconvert ended
        PIR1bits.ADIF = 0;
    }
    
    // I2C
    if(PIR1bits.SSPIF){
        // master : received ack
        // i2c_write/read disable interrupt
        if(which_am_i() == 0){
            PIR1bits.SSPIF = 0;
        }
        // slave : received from master
        if(which_am_i()){
            char mem = SSPBUF;
            if(SSPSTATbits.DA){
                data_i2c[i2c_data_cnt] = mem;
                
                /* FOR HALF PWM ***********************************************/
                if((signed char)data_i2c[0] == -128){
//                    free_flag = 1;
//                    rotate = 2;
                    data_i2c[0] = -127;
                }else{
                    if((signed char)data_i2c[0]>=-127 && (signed char)data_i2c[0]<=127)
                        data_i2c[0] += 0;
                } 
                if((signed char)data_i2c[0] < 0){
                    data_i2c[0] = (signed char)(-1*data_i2c[0]);
                    free_flag = 0;
                    rotate = 0;
                }else{
                    free_flag = 0;
                    rotate = 1;
                }
                //data_i2c[0] = data_i2c[0] * (LIMIT_30K-3) / 127 + 3;
                if(data_i2c[0] > LIMIT_22K){
                    data_i2c[0] = LIMIT_22K;
                }
                if(data_i2c[0] == 0){
                    rotate = 0;
                }
                /**************************************************************/
                time_out = 0;
                i2c_data_cnt++;
            }else if(SSPSTATbits.RW){
                SSPBUF = data_i2c[i2c_data_cnt];
            }else{
                i2c_data_cnt = 0;
            }
//            rotate = 0;
//            data_i2c[0] = 1;
            SSPCON1bits.CKP = 1;
            PIR1bits.SSPIF = 0;
        }
    }
    
    // UART
    if(PIR1bits.RCIF){ // serial receive
        data_serial = RCREG;
        PIR1bits.RCIF = 0;
    }
}

void main(void){
    init();
    //serial_init();
    i2c_init(1);
    md_init(1);
    intr_init();
    // 0:10K, 1:30k, 2:75k, 3:22k
    half_bridge_pwm_init(3);
    set_md_addr();
    change_rotate_half(0);
    set_duty_half(0);
    data_i2c[0] = 0;
    
    int turn = 0;
    
    while(1){

//        data_i2c[0]++;
//        
//        time_out = 0;
//        if((unsigned)data_i2c[0] == 128){
//            data_i2c[0] = 0;
//            rotate = !rotate;
//        }
//        __delay_ms(30);
        
        if(!PORTAbits.RA3){
            set_duty_half(0);
            set_md_addr();
        }
        INTCONbits.GIE = 0;
        change_rotate_half(rotate);
        rotate ? set_duty_half(FULL-data_i2c[0]): set_duty_half(data_i2c[0]);
        INTCONbits.GIE = 1;
        while(time_out > 100000){
            change_rotate_half(0);
            set_duty_half(0);
            if(!PORTAbits.RA3){
                set_md_addr();
            }
        }
        if(time_out < 100001)time_out++;
    }
}
#include "includes.h"

#define KP 0.42
#define KI 0.12
#define KD 0.03

#define KP2 0.14
#define KI2 0.012
#define KD2 0.0

#define KP3 0.18
#define KI3 0.02
#define KD3 0.0

////////////////////

#define KP22 0.29
#define KI22 0.02
#define KD22 0.0

#define KP23 0.15
#define KI23 0.02
#define KD23 0.0

////////////////////
#define GOTOFLAG 0
#define LED_ADDRESS 0x20

#define P_HEADER 0xA6
#define S_HEADER 0xB6

#define STANDBY 1
#define TORIKOMI 2
#define ITAAGE 3
#define HAKIDASHI 4
#define SHOKI 5
#define SERVO 6

#define BLUE_FIELD 0
#define RED_FIELD 1

DigitalOut myled1(PC_8);
DigitalOut myled2(PC_6);
DigitalOut myled3(PC_5);
DigitalIn sw(PC_4);
DigitalIn button(PB_12);
I2C i2c(PB_7,PB_8);
Serial pc(USBTX,USBRX);

PID pid(KP, KI, KD);
PID pidx(KP2, KI2, KD2);
PID pidy(KP3, KI3, KD3);

PID pidx2(KP2, KI2, KD2);
PID pidy2(KP3, KI3, KD3);

Serial serial(PB_6,PA_10);
Serial gyro(PA_11,PA_12);

OLED oled(&i2c);
OMNI omni(&i2c, &pid, &oled);

char R6093U_data[24];
float R6093U_before = 0;
float R6093U_act_before = 0;
float R6093U_get(char data_arr[], char sel);

void gyro_handler(){
    if(gyro.getc() == 0xA6){
        if(gyro.getc() == 0xA6){
            for(int cnt = 0; cnt < 7; cnt++){
                R6093U_data[cnt] = gyro.getc();
            }
        }
        else{
            return;
        }
    }
    else{
        return;
    }
}

char pc_data[6];
char pc_data_buckup[6];
char pc_cnt = 0;
char phase = 0;
char subphase = 0;
char my_phase = 0;
char my_subphase = 0;
signed short distance_x = 0;
signed short distance_y = 0;
char field_color = 0;
char field_mode = 0;
char towel = 0;

void pc_handler(){
    for(int i = 0; i < 6; i++){
        pc_data_buckup[i] = pc_data[i];
    }
    pc_data[0] = pc.getc();
    if(pc_data[0] >= 0x80){
        for(int cnt = 1; cnt < 6; cnt++){
            pc_data[cnt] = pc.getc();
            if(pc_data[cnt] >= 128){
                for(int j = 0; j < 6; j++){
                    pc_data[j] = pc_data_buckup[j];
                }
                break;
            }
        }
    }
    else{
        for(int j = 0; j < 6; j++){
            pc_data[j] = pc_data_buckup[j];
        }
    }
    
    field_color = (pc_data[0] & 0x10) > 0;
    field_mode = (pc_data[0] & 0x08) > 0;
    towel = (pc_data[0] & 0x04) > 0;
    phase = (char)((((short)pc_data[0] & 0x03) << 3) | (((short)pc_data[1] & 0x70) >> 4));
    distance_x = (short)(((pc_data[1] & 0x0C) << 12) + (pc_data[2] << 7) + pc_data[3]);
    distance_y = (short)(((pc_data[1] & 0x03) << 14) + (pc_data[4] << 7) + pc_data[5]);
    
    // 100cmtpp 0pppxxyy 0xxxxxxx 0xxxxxxx 0yyyyyyy 0yyyyyyy  (to send 2bytes + header, p:phase, x:distance_x, y:distance_y)
    return;
}

char uart_recv_data = 0;
char uart_num_tx = 0;
char uart_cnt;
char uart_address = 0x04; 
char uart_send_data[4] = {0};

void uart_receiving() {
    phase++;
    char buf;
    
    if(serial.getc() == 0xA6) {
        if(serial.getc() == 0xB6) {
            buf = serial.getc();
        }
        else 
            return;
    }
    else 
        return;
    uart_recv_data = buf;
}

void uart_sending(char address, char data){
    uart_num_tx  = data; 
    uart_address = address;
    if(uart_address > 0x0F){
        uart_address = 0;                      
    }    
    uart_send_data[0] = P_HEADER;          
    uart_send_data[1] = S_HEADER;          
    uart_send_data[2] = uart_address;          //address
    uart_send_data[3] = uart_num_tx;           //data of tx
    for(uart_cnt = 0; uart_cnt <= 3; uart_cnt++)
        serial.putc(uart_send_data[uart_cnt]);
}

int main(){
    gyro.baud(38400);
    pc.baud(19200);
    serial.baud(38400);

    oled.OLED_init();
    rotary_encoder_ab_phase e(TIM2, 24);
    e.start();
    
    gyro.printf("$MIB,RESET*87");
    wait(0.7);
    gyro.attach(gyro_handler, Serial::RxIrq);
    pc.attach(pc_handler, Serial::RxIrq);
    serial.attach(uart_receiving, Serial::RxIrq);
            
    //char d = 0;
    float z = 0;
    
    myled1 = 0;
    myled2 = 0;
    myled3 = 0;
    
    float pid_y = 0;
    float pid_x = 0;
    float angle = 0;
    int degree = 0;
    
    char moji[16] = {0};

    int speed_cnt = 0;
    int speed_max = 0;
    int speed_min = 0;

    char my_y = 0;
    float power = 0;
    char roller = 0;
    
    sprintf(moji, "STAND BY...");
    oled.OLED_printf(moji, 0);
    
    int gp = 1;
    
    while(!sw){
        my_y = (signed char)(distance_y * 0.06);
        i2c.write(LED_ADDRESS, &my_y, 1, 0);
        //roller = abs(distance_y) & 0x3F + 0x00 + 0;
//        uart_sending(0x04, roller);
//        roller = ((abs(distance_y) >> 6) & 0x3F) + 0x80 + 0;
//        uart_sending(0x04, roller);
//        roller = abs(distance_y) & 0x3F + 0x00 + 0x40;
//        uart_sending(0x04, roller);
//        roller = ((abs(distance_y) >> 6) & 0x3F) + 0x80 + 0x40;
//        uart_sending(0x04, roller);

        z = R6093U_get(R6093U_data, 'Z');
        sprintf(moji, "%7.2f", z);
        oled.OLED_printf(moji, 1);
        sprintf(moji, "p:%d c:%d m:%d t:%d", phase, field_color, field_mode, towel);
        oled.OLED_printf(moji, 2);
        sprintf(moji, "x:%5d y:%5d", abs(distance_y), abs(distance_x));
        oled.OLED_printf(moji, 3);
        if(field_color == BLUE_FIELD){
            omni.omni(0, 0, 0, z, 0);
        }
        else{
            omni.omni_b2r(0, 0, 0, z, 0);
        }
        if(button){
            uart_recv_data = 0;
            uart_sending(0x01, gp);
            wait(0.5);
            sprintf(moji, "gp:%d get:%d", gp, uart_recv_data);
            oled.OLED_printf(moji, 4);
            gp++;
            if(gp > 6){
                gp = 1;
            }
        }
        sprintf(moji, "gp:%d get:%d", gp, uart_recv_data);
        oled.OLED_printf(moji, 4);
    }
    
    sprintf(moji, "PLAY NOW");
    oled.OLED_printf(moji, 0);
    
    degree = 0;
    speed_max = 900;
    speed_min = 0;
    speed_cnt = speed_min;
    subphase = 0;
    uart_recv_data = 0;
    if(GOTOFLAG){
        uart_sending(0x01, ITAAGE);
        while(!uart_recv_data){
            i2c.write(LED_ADDRESS, &my_y, 1, 0);
        }
    }
    while(1)
    {
        my_y = (signed char)(distance_y * 0.07);
        i2c.write(LED_ADDRESS, &my_y, 1, 0);
        z = R6093U_get(R6093U_data, 'Z');
        switch(phase){
            case 0:{
                switch(subphase){
                    case 0:{
                        degree = 0;
                        if(distance_y > 140){
                            pid_y = pidy.get_pid(distance_x, 55);
                            pid_x = pidx.get_pid(distance_y, 130);
                        }
                        else{
                            pid_y = pidy.get_pid(distance_x, 46);
                            pid_x = pidx.get_pid(distance_y, 120);
                        }
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power < 4){
                            subphase = 1;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 10 && power > 1) power = 10;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, (int)power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, (int)power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                                speed_cnt++;
                        my_subphase = 0;
                    } break;
                    case 1:{
                        if(my_subphase != 1){
                            degree = 0;
                            speed_max = 900;
                            speed_min = 10;
                            speed_cnt = speed_min;
                            for(int p = 0; p < 100; p++){
                                z = R6093U_get(R6093U_data, 'Z');
                                if(field_color == BLUE_FIELD){
                                    omni.omni(0, 10, 0, z, 0);
                                }
                                else{
                                    omni.omni_b2r(0, 10, 0, z, 0);
                                }
                                i2c.write(LED_ADDRESS, &my_y, 1, 0);
                            }
                            if(GOTOFLAG){
                                uart_recv_data = 0;
                                uart_sending(0x01, STANDBY);
                                while(!uart_recv_data){
                                    i2c.write(LED_ADDRESS, &my_y, 1, 0);
                                }
                            }
                        }
                        if(towel == 0){
                            pid_y = pidy.get_pid(distance_x, 46);
                            pid_x = -10;
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                        }
                        else{
                            pid_y = pidy.get_pid(distance_x, 44);
                            pid_x = 0;
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                            if(GOTOFLAG){
                                uart_recv_data = 0;
                                uart_sending(0x01, TORIKOMI);
                                while(!uart_recv_data){
                                    z = R6093U_get(R6093U_data, 'Z');
                                    if(field_color == BLUE_FIELD){
                                        omni.omni(0, 8, 0, z, 0);
                                    }
                                    else{
                                        omni.omni_b2r(0, 8, 0, z, 0);
                                    }
                                    i2c.write(LED_ADDRESS, &my_y, 1, 0);
                                }
                                uart_recv_data = 0;
                                uart_sending(0x01, STANDBY);
                                while(!uart_recv_data){
                                    i2c.write(LED_ADDRESS, &my_y, 1, 0);
                                    z = R6093U_get(R6093U_data, 'Z');
                                    if(field_color == BLUE_FIELD){
                                        omni.omni(0, 8, 0, z, 0);
                                    }
                                    else{
                                        omni.omni_b2r(0, 8, 0, z, 0);
                                    }
                                }
                            }
                        }
                        if(distance_y > 276){
                            pid_y = pidy.get_pid(distance_x, 40);
                            pid_x = pidx.get_pid(distance_y, 270);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                        }
                        my_subphase = 1;
                    } break;
                }
                my_phase = 0;
            } break;
            case 1:{
                if(my_phase != 1){
                    for(int p = 0; p < 500; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(field_color == BLUE_FIELD){
                            omni.omni(-85, 9, 0, z, 0);
                        }
                        else{
                            omni.omni_b2r(-85, 9, 0, z, 0);
                        }
                    }
                    if(GOTOFLAG){
                        uart_recv_data = 0;
                        uart_sending(0x01, TORIKOMI);
                        while(!uart_recv_data){
                            i2c.write(LED_ADDRESS, &my_y, 1, 0);
                            z = R6093U_get(R6093U_data, 'Z');
                            if(field_color == BLUE_FIELD){
                                omni.omni(0, 8, 0, z, 0);
                            }
                            else{
                                omni.omni_b2r(0, 8, 0, z, 0);
                            }
                        }
                    }
                    for(int p = 0; p < 600; p++){
                        i2c.write(LED_ADDRESS, &my_y, 1, 0);
                        z = R6093U_get(R6093U_data, 'Z');
                        if(field_color == BLUE_FIELD){
                            omni.omni(-180, 9, 0, z, 0);
                        }
                        else{
                            omni.omni_b2r(-160, 9, 0, z, 0);
                        }
                    }
                    degree = -90;
                    speed_max = 900;
                    speed_min = 0;
                    speed_cnt = speed_min;
                }
                if(z > 0){
                    z = -360+z;
                }
                if(z > -80||z < -350){
                    if(field_color == BLUE_FIELD){
                        omni.omni(170, 12, -18, (int)z, (int)z);
                    }
                    else{
                        omni.omni_b2r(170, 12, -18, (int)z, (int)z);
                    }
                }
                else if(distance_y < 300){
                    pid_y = -pidy.get_pid(distance_x, 256);
                    pid_x = pidx.get_pid(distance_y, 380);
                    angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + -90;
                    power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                    if(power < 4 && power > 1) power = 4;
                    if(field_color == BLUE_FIELD){
                        omni.omni(angle, (int)power, 0, z, degree);
                    }
                    else{
                        omni.omni_b2r(angle, (int)power, 0, z, degree);
                    }
                    if(speed_cnt < speed_max)
                        speed_cnt++;
                }
                else{
                    pid_y = -pidy.get_pid(distance_x, 250);
                    pid_x = pidx.get_pid(distance_y, 500);
                    angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + -90;
                    power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                    if(power < 8 && power > 1) power = 8;
                    if(field_color == BLUE_FIELD){
                        omni.omni(angle, (int)power, 0, z, degree);
                    }
                    else{
                        omni.omni_b2r(angle, (int)power, 0, z, degree);
                    }
                }
                my_phase = 1;
            } break;
            case 2:{
                if(my_phase != 2){
                    speed_max = 600;
                    speed_min = 50;
                    speed_cnt = speed_min;
                    degree = -90;
                    subphase = 0;
                    my_subphase = 0;
                    if(z > 0){
                        z = -360+z;
                    }
                    for(int p = 0; p < 300; p++){
                        z = R6093U_get(R6093U_data, 'Z');
                        if(field_color == BLUE_FIELD){
                            omni.omni(0, 8, 0, z, -90);
                        }
                        else{
                            omni.omni_b2r(0, 8, 0, z, -90);
                        }
                    }
                    if(GOTOFLAG){
                        uart_recv_data = 0;
                        uart_sending(0x01, HAKIDASHI);
                        while(!uart_recv_data);
                        uart_recv_data = 0;
                        uart_sending(0x01, SHOKI);
                        while(!uart_recv_data);
                    }
                    while(!sw);
                }
                if(z > 0){
                    z = -360+z;
                }
                switch(subphase){
                    case 0:{
                        if(subphase != 0){
                            speed_max = 600;
                            speed_min = 50;
                            speed_cnt = speed_min;
                        }
                        if(distance_y > 150 || distance_x < 370){
                            pid_y = pidy.get_pid(distance_x, 380);
                            pid_x = pidx.get_pid(distance_y, 140);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 4 && power > 1) power = 4;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                            if(speed_cnt < speed_max)
                                speed_cnt++;
                        }
                        else{
                            pid_y = -10;
                            pid_x = pidx.get_pid(distance_y, 140);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                        }
                        if(distance_x > 410){
                            subphase = 1;
                        }
                        my_subphase = 0;
                    } break;
                    case 1:{
                        if(my_subphase != 1){
                            speed_max = 600;
                            speed_min = 50;
                            speed_cnt = speed_min;
                            degree = -90;
                            
                            while(distance_x > 380){
                                z = R6093U_get(R6093U_data, 'Z');
                                if(z > 0){
                                    z = -360+z;
                                }
                                pid_y = 10;
                                pid_x = pidx.get_pid(distance_y, 140);
                                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                                if(power < 8 && power > 1) power = 8;
                                if(field_color == BLUE_FIELD){
                                    omni.omni(angle, (int)power, 0, z, degree);
                                }
                                else{
                                    omni.omni_b2r(angle, (int)power, 0, z, degree);
                                }
                            }
                        }
                        if(distance_y < 205){
                            pid_y = pidy.get_pid(distance_x, 380);
                            pid_x = pidx.get_pid(distance_y, 210);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 4 && power > 1) power = 4;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                            if(speed_cnt < speed_max)
                                speed_cnt++;
                        }
                        else{
                            pid_y = -10;
                            pid_x = pidx.get_pid(distance_y, 210);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                        }
                        if(distance_x > 410){
                            subphase = 2;
                        }
                        my_subphase = 1;
                    } break;
                    case 2:{
                        if(my_subphase != 2){
                            speed_max = 600;
                            speed_min = 50;
                            speed_cnt = speed_min;
                            degree = -90;
                            
                            while(distance_x > 380){
                                if(z > 0){
                                    z = -360+z;
                                }
                                z = R6093U_get(R6093U_data, 'Z');
                                pid_y = 10;
                                pid_x = pidx.get_pid(distance_y, 210);
                                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                                if(power < 8 && power > 1) power = 8;
                                if(field_color == BLUE_FIELD){
                                    omni.omni(angle, (int)power, 0, z, degree);
                                }
                                else{
                                    omni.omni_b2r(angle, (int)power, 0, z, degree);
                                }
                            }
                        }
                        if(distance_y < 300){
                            pid_y = pidy.get_pid(distance_x, 250);
                            pid_x = pidx.get_pid(distance_y, 320);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 4 && power > 1) power = 4;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                            if(speed_cnt < speed_max)
                                speed_cnt++;
                        }
                        else{
                            pid_y = pidy.get_pid(distance_x, 250);
                            pid_x = pidx.get_pid(distance_y, 500);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + degree;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, (int)power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, (int)power, 0, z, degree);
                            }
                        }
                        my_subphase = 2;
                    } break;
                }
                
                my_phase = 2;
            } break;
            case 3:{
                if(my_phase != 3){
                    speed_max = 1000;
                    speed_min = 10;
                    speed_cnt = speed_min;
                    subphase = 0;
                    my_subphase = 0;
                    if(GOTOFLAG){
                        uart_recv_data = 0;
                        uart_sending(0x01, HAKIDASHI);
                        while(!uart_recv_data);
                        uart_recv_data = 0;
                        uart_sending(0x01, SHOKI);
                    }
                    while(!sw);
                    gyro.printf("$MIB,RESET*87");
                    gyro.printf("$MIB,RESET*87");
                    wait(0.5);
                    gyro.printf("$MIB,RESET*87");
                    gyro.printf("$MIB,RESET*87");
                    wait(0.7);
                }
                degree = 0;
                switch(subphase){
                    case 0:{
                        for(int l = 0; l < 140; l++){
                            z = R6093U_get(R6093U_data, 'Z');
                            roller = l & 0x3F + 0x00 + 0;
                            uart_sending(0x04, roller);
                            roller = ((l >> 6) & 0x3F) + 0x80 + 0;
                            uart_sending(0x04, roller);
                            roller = l & 0x3F + 0x00 + 0x40;
                            uart_sending(0x04, roller);
                            roller = ((l >> 6) & 0x3F) + 0x80 + 0x40;
                            uart_sending(0x04, roller);
                            if(field_color == BLUE_FIELD){
                                omni.omni(0, 0, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(0, 0, 0, z, degree);
                            }
                            for(int i = 0; i < 100; i++);
                        }
                        while(!sw);
                        subphase = 1;
                        my_subphase = 0;
                        speed_cnt = 0;
                    } break;
                    case 1:{
                        while(distance_x < 745){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 500);
                            pid_y = -pidy.get_pid(distance_x, 750);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < (speed_max - 100))
                                speed_cnt++;
                        }
                        speed_cnt = 10;
                        subphase = 2;
                        my_subphase = 1;
                    } break;
                    case 2:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 320);
                        pid_y = -pidy.get_pid(distance_x, 750);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 2){
                            subphase = 3;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 2;
                    } break;
                    case 3:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 320);
                        pid_y = -pidy.get_pid(distance_x, 845);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 2){
                            subphase = 4;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 3;
                    } break;
                    case 4:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 345);
                        pid_y = -pidy.get_pid(distance_x, 845);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(distance_y > 340){
                            subphase = 5;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 4;
                    } break;
                    case 5:{
                        for(int p = 0; p < 200; p++){
                            z = R6093U_get(R6093U_data, 'Z');
                            angle = 90 - 90;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, 9, 0, z, 0);
                            }
                            else{
                                omni.omni_b2r(angle, 9, 0, z, 0);
                            }
                        }
                        
                        while(distance_y > 150){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -10;
                            pid_y = -pidy.get_pid(distance_x, 845)*1.5f;
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                        }
                        
                        for(int p = 0; p < 200; p++){
                            z = R6093U_get(R6093U_data, 'Z');
                            angle = -90 - 90;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, 9, 0, z, 0);
                            }
                            else{
                                omni.omni_b2r(angle, 9, 0, z, 0);
                            }
                        }
                        subphase = 6;
                        my_subphase = 5;
                    } break;
                    case 6:{
                        if(my_subphase != 6){
                            speed_cnt = 0;
                            while(distance_x > 760){
                                z = R6093U_get(R6093U_data, 'Z');
                                pid_x = -pidx.get_pid(distance_y, 160);
                                pid_y = -pidy.get_pid(distance_x, 755);
                                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                                if(power < 10 && power > 1) power = 10;
                                power = power*speed_cnt/speed_max;
                                if(speed_cnt < speed_max)
                                    speed_cnt++;
                                if(field_color == BLUE_FIELD){
                                    omni.omni(angle, power, 0, z, degree);
                                }
                                else{
                                    omni.omni_b2r(angle, power, 0, z, degree);
                                }
                            }
                            speed_cnt = 0;
                        }
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 500);
                        pid_y = -pidy.get_pid(distance_x, 780) * 1.3f;
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 3){
                            subphase = 7;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max - 100)
                            speed_cnt++;
                        my_subphase = 6;
                    } break;
                    case 7:{
                        speed_cnt = 0;
                        while(distance_x > 60){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -pidx.get_pid(distance_y, 500);
                            pid_y = -pidy.get_pid(distance_x, 60);
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*speed_cnt/speed_max;
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                            if(speed_cnt < speed_max - 100)
                                speed_cnt++;
                        }
                        speed_cnt = 0;
                        phase = 5;
                        my_subphase = 7;
                    } break;
                    default: break;
                }
                my_phase = 3;
            } break;
            case 4:{
                subphase = 0;
                my_subphase = 0;                
                phase = 3;
                my_phase = 4;
            } break;
            case 5:{
                if(my_phase != 5){
                    speed_max = 900;
                    speed_min = 0;
                    speed_cnt = speed_min;
                    subphase = 0;
                    while(!sw);
                    gyro.printf("$MIB,RESET*87");
                    gyro.printf("$MIB,RESET*87");
                    wait(0.5);
                    gyro.printf("$MIB,RESET*87");
                    gyro.printf("$MIB,RESET*87");
                    wait(0.7);
                }
                degree = 0;
                switch(subphase){
                    case 0:{
                        speed_cnt = 0;
                        
                        for(int l = 0; l < 140; l++){
                            z = R6093U_get(R6093U_data, 'Z');
                            roller = l & 0x3F + 0x00 + 0;
                            uart_sending(0x04, roller);
                            roller = ((l >> 6) & 0x3F) + 0x80 + 0;
                            uart_sending(0x04, roller);
                            roller = l & 0x3F + 0x00 + 0x40;
                            uart_sending(0x04, roller);
                            roller = ((l >> 6) & 0x3F) + 0x80 + 0x40;
                            uart_sending(0x04, roller);
                            if(field_color == BLUE_FIELD){
                                omni.omni(0, 0, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(0, 0, 0, z, degree);
                            }
                            for(int i = 0; i < 100; i++);
                        }
                        
                        while(!sw);
                        my_subphase = 0;
                        subphase = 1;
                        speed_cnt = 0;
                    } break;
                    case 1:{
                        if(my_subphase != 1){
                            for(int i = 0; i<2000; i++){
                                z = R6093U_get(R6093U_data, 'Z');
                                if(field_color == BLUE_FIELD){
                                    omni.omni(-90, 18, 0, z, degree);
                                }
                                else{
                                    omni.omni_b2r(-90, 18, 0, z, degree);
                                }
                            }
                        }
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 500);
                        pid_y = -pidy.get_pid(distance_x, 545);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power < 5){
                            speed_cnt = 0;
                            subphase = 2;
                            my_subphase = 1;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 10 && power > 1) power = 10;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < (speed_max - 200))
                            speed_cnt++;
                        my_subphase = 1;
                    } break;
                    case 2:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 320);
                        pid_y = -pidy.get_pid(distance_x, 545);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 2){
                            subphase = 3;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 10 && power > 1) power = 10;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 2;
                    } break;
                    case 3:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 320);
                        pid_y = -pidy.get_pid(distance_x, 645);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 2){
                            subphase = 4;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 10 && power > 1) power = 10;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 3;
                    } break;
                    case 4:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 345);
                        pid_y = -pidy.get_pid(distance_x, 645);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(distance_y > 335){
                            subphase = 5;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 10 && power > 1) power = 10;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max)
                            speed_cnt++;
                        my_subphase = 4;
                    } break;
                    case 5:{
                        for(int p = 0; p < 200; p++){
                            z = R6093U_get(R6093U_data, 'Z');
                            angle = 90 - 90;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, 9, 0, z, 0);
                            }
                            else{
                                omni.omni_b2r(angle, 9, 0, z, 0);
                            }
                        }
                        
                        while(distance_y > 150){
                            z = R6093U_get(R6093U_data, 'Z');
                            pid_x = -10;
                            pid_y = -pidy.get_pid(distance_x, 645)*1.5f;
                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                            if(power < 8 && power > 1) power = 8;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, power, 0, z, degree);
                            }
                            else{
                                omni.omni_b2r(angle, power, 0, z, degree);
                            }
                        }
                        
                        for(int p = 0; p < 200; p++){
                            z = R6093U_get(R6093U_data, 'Z');
                            angle = -90 - 90;
                            if(field_color == BLUE_FIELD){
                                omni.omni(angle, 9, 0, z, 0);
                            }
                            else{
                                omni.omni_b2r(angle, 9, 0, z, 0);
                            }
                        }
                        subphase = 6;
                        my_subphase = 5;
                    } break;
                    case 6:{
                        if(my_subphase != 6){
                            speed_cnt = 0;
                            while(distance_x > 570){
                                z = R6093U_get(R6093U_data, 'Z');
                                pid_x = -pidx.get_pid(distance_y, 160);
                                pid_y = -pidy.get_pid(distance_x, 555);
                                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                                if(power < 10 && power > 1) power = 10;
                                power = power*speed_cnt/speed_max;
                                if(speed_cnt < speed_max)
                                    speed_cnt++;
                                if(field_color == BLUE_FIELD){
                                    omni.omni(angle, power, 0, z, degree);
                                }
                                else{
                                    omni.omni_b2r(angle, power, 0, z, degree);
                                }
                            }
                            speed_cnt = 0;
                        }
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 500);
                        pid_y = -pidy.get_pid(distance_x, 580) * 1.3f;
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(power <= 6){
                            speed_cnt = 10;
                            subphase = 7;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 8 && power > 1) power = 8;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < speed_max - 100)
                            speed_cnt++;
                        my_subphase = 6;
                    } break;
                    case 7:{
                        z = R6093U_get(R6093U_data, 'Z');
                        pid_x = -pidx.get_pid(distance_y, 500);
                        pid_y = -pidy.get_pid(distance_x, 200);
                        angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI - 90;
                        power = sqrt(pow(pid_x,2)+pow(pid_y,2));
                        if(sw){
                            speed_cnt = 0;
                            phase = 6;
                        }
                        power = power*speed_cnt/speed_max;
                        if(power < 12 && power > 1) power = 12;
                        if(field_color == BLUE_FIELD){
                            omni.omni(angle, power, 0, z, degree);
                        }
                        else{
                            omni.omni_b2r(angle, power, 0, z, degree);
                        }
                        if(speed_cnt < (speed_max - 600))
                            speed_cnt++;
                        my_subphase = 7;
                    } break;
                    default: break;
                }
                my_phase = 5;
            } break;
            case 6:{
                subphase = 0;
                my_subphase = 0;                
                phase = 5;
                my_phase = 6;
            } break;
            case 7:{
                my_phase = 7;
            } break;
            case 8:{
                my_phase = 8;
            } break;
            case 9:{
                my_phase = 9;
            } break;
            default :break;
        }
        
        if(sw){
            myled1 = 1;
            myled2 = !button;
            myled3 = !sw;
        }
        else{
            myled1 = 0;
            myled2 = 0;
            myled3 = 0;
        }
        
//        d = e.get_counts();
//        oled.OLED_bar(0, 7, (char)d);
//        oled.OLED_line_clear(7, (char)d);
//        sprintf(moji, "x:%5d y:%5d", (int)distance_x, (int)distance_y);
//        oled.OLED_printf(moji, 3);
//        sprintf(moji, "p:%d", phase);
//        oled.OLED_printf(moji, 2);
//        sprintf(moji, "%7.2f", z);
//        oled.OLED_printf(moji, 1);
    }
}

float R6093U_get(char data_arr[], char sel) {
    signed short angle = 0;
    float ang = 0;
    
    switch(sel){
        case 'X': angle = data_arr[1] | (data_arr[2]<<8); break;
        case 'Y': angle = data_arr[3] | (data_arr[4]<<8); break;
        case 'Z': angle = data_arr[5] | (data_arr[6]<<8); break;
        default : angle = 0; break;
    }
    
    ang = angle * (float)0.01;
    if((abs(ang)-abs(R6093U_act_before)) > 30){
        R6093U_act_before = ang;
        ang = R6093U_before;
    }
    else{
        R6093U_act_before = ang;
    }
    R6093U_before = ang;
    if(field_color == RED_FIELD){
        return -ang;
    }
    else{
        return ang;
    }
}
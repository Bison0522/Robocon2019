//#include "includes.h"
//
//#define KP 0.63
//#define KI 0.11
//#define KD 0.0
//
//#define KP2 0.15
//#define KI2 0.01
//#define KD2 0.0
//
//#define KP3 0.11
//#define KI3 0.05
//#define KD3 0.01
//
//////////////////////
//
//#define KP22 0.3
//#define KI22 0.2
//#define KD22 0.0
//
//#define KP23 0.11
//#define KI23 0.05
//#define KD23 0.0
//
//////////////////////
//
//#define LED_ADDRESS 0x20
//
//#define P_HEADER 0xA6
//#define S_HEADER 0xB6
//
//#define TORIKOMI 1
//#define HAKIDASHI 2
//#define SHOKI 3
//
//DigitalOut myled1(PC_8);
//DigitalOut myled2(PC_6);
//DigitalOut myled3(PC_5);
//DigitalIn sw(PC_4);
//DigitalIn button(PB_12);
//I2C i2c(PB_7,PB_8);
//Serial pc(USBTX,USBRX);
//
//PID pid(KP, KI, KD);
//PID pidx(KP2, KI2, KD2);
//PID pidy(KP3, KI3, KD3);
//
//PID pidx2(KP22, KI22, KD22);
//PID pidy2(KP23, KI23, KD23);
//
//Serial serial(PB_6,PA_10);
//Serial gyro(PA_11,PA_12);
//
//OLED oled(&i2c);
//OMNI omni(&i2c, &pid, &oled);
//
//char R6093U_data[24];
//float R6093U_before = 0;
//float R6093U_act_before = 0;
//float R6093U_get(char data_arr[], char sel);
//
//void gyro_handler(){
//    if(gyro.getc() == 0xA6){
//        if(gyro.getc() == 0xA6){
//            for(int cnt = 0; cnt < 7; cnt++){
//                R6093U_data[cnt] = gyro.getc();
//            }
//        }
//        else{
//            return;
//        }
//    }
//    else{
//        return;
//    }
//}
//
//char pc_data[6];
//char pc_data_buckup[6];
//char pc_cnt = 0;
//char phase = 0;
//char subphase = 0;
//char my_phase = 0;
//char my_subphase = 0;
//signed short distance_x = 0;
//signed short distance_y = 0;
//
//void pc_handler(){
//    for(int i = 0; i < 6; i++){
//        pc_data_buckup[i] = pc_data[i];
//    }
//    pc_data[0] = pc.getc();
//    if(pc_data[0] >= 0x80){
//        for(int cnt = 1; cnt < 6; cnt++){
//            pc_data[cnt] = pc.getc();
//            if(pc_data[cnt] >= 128){
//                for(int j = 0; j < 6; j++){
//                    pc_data[j] = pc_data_buckup[j];
//                }
//                break;
//            }
//        }
//    }
//    else{
//        for(int j = 0; j < 6; j++){
//            pc_data[j] = pc_data_buckup[j];
//        }
//    }
//    
//    phase = ((pc_data[0] & 0x0F) << 4) + ((pc_data[1] & 0xF0) >> 4);
//    distance_x = (short)(((pc_data[1] & 0x0C) << 12) + (pc_data[2] << 7) + pc_data[3]);
//    distance_y = (short)(((pc_data[1] & 0x03) << 14) + (pc_data[4] << 7) + pc_data[5]);
//    
//    // 1000pppp ppppxxyy 0xxxxxxx 0xxxxxxx 0yyyyyyy 0yyyyyyy  (to send 2bytes + header, p:phase, x:distance_x, y:distance_y)
//    return;
//}
//
//char uart_recv_data = 0;
//char uart_num_tx = 0;
//char uart_cnt;
//char uart_address = 0x04; 
//char uart_send_data[4] = {0};
//
//void uart_receiving() {
//    phase++;
//    char buf;
//    
//    if(serial.getc() == 0xA6) {
//        if(serial.getc() == 0xB6) {
//            buf = serial.getc();
//        }
//        else 
//            return;
//    }
//    else 
//        return;
//    uart_recv_data = buf;
//}
//
//void uart_sending(char address, char data){
//    uart_num_tx  = data; 
//    uart_address = address;
//    if(uart_address > 0x0F){
//        uart_address = 0;                      
//    }    
//    uart_send_data[0] = P_HEADER;          
//    uart_send_data[1] = S_HEADER;          
//    uart_send_data[2] = uart_address;          //address
//    uart_send_data[3] = uart_num_tx;           //data of tx
//    for(uart_cnt = 0; uart_cnt <= 3; uart_cnt++)
//        serial.putc(uart_send_data[uart_cnt]);
//}
//
//int main(){
//    gyro.baud(38400);
//    pc.baud(19200);
//    serial.baud(38400);
//
//    oled.OLED_init();
//    rotary_encoder_ab_phase e(TIM2, 24);
//    e.start();
//    
//    gyro.printf("$MIB,RESET*87");
//    wait(0.5);
//    gyro.attach(gyro_handler, Serial::RxIrq);
//    pc.attach(pc_handler, Serial::RxIrq);
//    serial.attach(uart_receiving, Serial::RxIrq);
//            
//    char d = 0;
//    float z = 0;
//    
//    myled1 = 0;
//    myled2 = 0;
//    myled3 = 0;
//    
//    float pid_y = 0;
//    float pid_x = 0;
//    float angle = 0;
//    int degree = 0;
//    
//    char moji[16] = {0};
//    char decoration = 0;
//    //char dec_cnt = 0;
//    //char dec_color = 0;
//    
//    int phase0_cnt = 0;
//    int phase1_cnt = 0;
//    int phase2_cnt = 50;
//    int phase3_cnt = 0;
//    int phase4_cnt = 0;
//    int phase5_cnt = 0;
//    int phase6_cnt = 0;
//    char my_y = 0;
//    float power = 0;
//    char roller = 0;
//    
//    sprintf(moji, "STAND BY...");
//    oled.OLED_printf(moji, 0);
//    while(!sw){
//    //char ph = 1;
//    //while(1){
//        my_y = (signed char)(distance_y * 0.06);
//        i2c.write(LED_ADDRESS, &my_y, 1, 0);
//        roller = abs(distance_y) & 0x3F + 0x00 + 0;
//        uart_sending(0x04, roller);
//        roller = ((abs(distance_y) >> 6) & 0x3F) + 0x80 + 0;
//        uart_sending(0x04, roller);
//        roller = abs(distance_x) & 0x3F + 0x00 + 0x40;
//        uart_sending(0x04, roller);
//        roller = ((abs(distance_x) >> 6) & 0x3F) + 0x80 + 0x40;
//        uart_sending(0x04, roller);
//        
////        if(decoration == 50){
////            dec_cnt = 0;
////        }
////        else if(decoration == 0){
////            dec_cnt = 1;
////            dec_color = !dec_color;
////        }
////        else if((signed char)decoration == -50){
////            dec_cnt = 0;
////        }
////        if(dec_color){
////            dec_cnt ? decoration += 5 : decoration -= 5;
////        }
////        else{
////            dec_cnt ? decoration -= 5 : decoration += 5;
////        }
//        z = R6093U_get(R6093U_data, 'Z');
//        sprintf(moji, "%7.2f", z);
//        oled.OLED_printf(moji, 1);
////        sprintf(moji, "p:%d,r:%3d", phase, uart_recv_data);
////        oled.OLED_printf(moji, 2);
//        omni.omni(0, 0, 0, z, 0);
////        d = e.get_counts();
////        oled.OLED_bar(0, 7, (char)d);
////        oled.OLED_line_clear(7, (char)d);
////        if(sw){
////            uart_sending(0x01, ph);
////            uart_recv_data = 5;
////            ph++;
////            if(ph == 4) ph = 1;
////            wait_ms(1000);
////        }
//    }
//    
//    sprintf(moji, "PLAY NOW");
//    oled.OLED_printf(moji, 0);   
//    
//    while(1)
//    {
//        my_y = (signed char)(distance_y * 0.07);
//        i2c.write(LED_ADDRESS, &my_y, 1, 0);
//        z = R6093U_get(R6093U_data, 'Z');
//        
//        switch(phase){
//            case 0:{ // start zone 2
//                //degree = 0;
////                pid_y = -pidy.get_pid(distance_y, 62);
////                pid_x = -pidx.get_pid(distance_x, 62);
////                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI;
////                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
////                if(power < 6 && power > 0.8) power = 6;
////                omni.omni(angle, (int)power, 0, z, degree);
////                my_phase = 0;
//                omni.omni(0, 10, 0, z, 0);
//            } break;
//            case 1:{ // go to zone t
//                degree = 0;
//                pid_y = pidy.get_pid(distance_y, 65);
//                pid_x = -pidx.get_pid(distance_x, 50);
//                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI;
//                power = sqrt(pow(pid_x,2)+pow(pid_y,2))*phase1_cnt/500;
//                if(power < 7 && power > 0.4) power = 7;
//                omni.omni(angle, (int)power, 0, z, degree);
//                my_phase = 1;
//                if(phase1_cnt < 500)
//                    phase1_cnt++;
//            } break;
//            case 2:{ // help zone
//                if(my_phase == 1){
//                    for(int p = 0; p < 700; p++){
//                        z = R6093U_get(R6093U_data, 'Z');
//                        omni.omni(0, 10, 0, z, 0);
//                    }
////                    uart_recv_data = 0;
////                    uart_sending(0x01, TORIKOMI);
////                    while(!uart_recv_data);
//                    for(int p = 0; p < 600; p++){
//                        z = R6093U_get(R6093U_data, 'Z');
//                        omni.omni(180, 10, 0, z, 0);
//                    }
//                }
//                if(z > 0){
//                    z = -360+z;
//                }
//                if(z < -225 || z > -80){
//                    omni.omni(160, 23, 23, (int)z, (int)z);
//                }
//                else{
//                    degree = -180;
//                    pid_y = pidy.get_pid(distance_y, 65);
//                    pid_x = pidx.get_pid(distance_x, 47);
//                    angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 180;
//                    power = sqrt(pow(pid_x,2)+pow(pid_y,2))*phase2_cnt/300;
//                    if(power < 7 && power > 0.6) power = 7;
//                    omni.omni(angle, power, 0, z, degree);
//                    if(phase2_cnt < 300)
//                        phase2_cnt++;
//                }
//                my_phase = 2;
//            } break;
//            case 3:{ // go hanging 0-2
//                if(z > 0){
//                    z = -360+z;
//                }
//                if(my_phase == 2){
//                    for(int p = 0; p < 600; p++){
//                        z = R6093U_get(R6093U_data, 'Z');
//                        omni.omni(180, 10, 0, z, -180);
//                    }
////                    uart_recv_data = 0;
////                    uart_sending(0x01, HAKIDASHI);
////                    while(!uart_recv_data);
////                    uart_sending(0x01, SHOKI);
////                    while(!uart_recv_data);
//                    phase3_cnt = 0;
//                    subphase = 0;
//                    while(!sw);
//                    for(int p = 0; p < 200; p++){
//                        z = R6093U_get(R6093U_data, 'Z');
//                        omni.omni(0, 10, 0, z, -180);
//                    }
//                }
//                if(z > -260){
//                    omni.omni(75, 25, -25, (int)z, (int)z);
//                }
//                else{
//                    switch(subphase){
//                        case 0:{
//                            degree = -270;
//                            pid_x = -pidx2.get_pid(distance_y, 320);
//                            pid_y = -pidy2.get_pid(distance_x, 425);
//                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 90;
//                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
//                            if(power < 7 && power > 0.5) power = 7;
//                            omni.omni(angle, power, 0, z, degree);
//                            if(distance_x < 428 && distance_x > 422 && distance_y < 336 && distance_y > 330){
//                                subphase = 1;
//                            }
//                            my_subphase = 0;
//                        } break;
//                        case 1:{
//                            degree = -270;
//                            if(my_subphase == 0){
//                                phase3_cnt = 0;
//                                while(distance_x > 380){
//                                    z = R6093U_get(R6093U_data, 'Z');
//                                    omni.omni(-90, 9, 0, z, degree);
//                                }
//                                while(distance_y > 296){
//                                    z = R6093U_get(R6093U_data, 'Z');
//                                    omni.omni(0, 9, 0, z, degree);
//                                }
//                            }
//                            pid_x = -pidx.get_pid(distance_y, 295);
//                            pid_y = -pidy.get_pid(distance_x, 430);
//                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 90;
//                            power = sqrt(pow(pid_x,2)+pow(pid_y,2));
//                            if(power < 7 && power > 0.2) power = 7;
//                            omni.omni(angle, power, 0, z, degree);
//                            if(distance_x < 433 && distance_x > 427 && distance_y < 298 && distance_y > 292){
//                                subphase = 2;
//                            }
//                            my_subphase = 1;
//                        } break;
//                        case 2:{
//                            degree = -270;
//                            if(my_subphase == 1){
//                                phase3_cnt = 0;
//                                while(distance_y > 300){
//                                    z = R6093U_get(R6093U_data, 'Z');
//                                    omni.omni(-90, 17, 0, z, degree);
//                                }
//                            }
//                            degree = -270;
//                            pid_x = -pidx2.get_pid(distance_y, 380);
//                            pid_y = -pidy2.get_pid(distance_x, 60);
//                            angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 90;
//                            power = sqrt(pow(pid_x,2)+pow(pid_y,2))*phase3_cnt/500;
//                            if(power < 7 && power > 0.5) power = 7;
//                            omni.omni(angle, power, 0, z, degree);
//                            if(phase3_cnt < 500)
//                                phase3_cnt++;
//                            my_subphase = 2;
//                        } break;
//                        default: break;
//                    }
//                }
//                my_phase = 3;
//            } break;
//            case 4:{
//                if(z > 0){
//                    z = -360+z;
//                }
//                if(my_phase == 3){
//                    while(!sw);
//                    subphase = 0;
//                }
//                if(z < -225){
//                    omni.omni(75, 25, 25, (int)z, (int)z);
//                }
//                else{
//                    degree = -180;
//                    angle = 0;
//                    power = 0;
//                    omni.omni(angle, power, 0, z, degree);
//                    sprintf(moji, "%7.2f", z);
//                    oled.OLED_printf(moji, 1);
//                }
//
//                //else{
////                    degree = -180;
////                    switch(subphase){
////                        case 0:{
////                            while(distance_x < 280){
////                                //degree = -180;
////                                //pid_y = -pidy.get_pid(distance_y, 390);
////                                //pid_x = pidx.get_pid(distance_x, 330);
////                                //angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 180;
////                                //power = sqrt(pow(pid_x,2)+pow(pid_y,2))*phase4_cnt/300;
////                                //if(power < 7 && power > 0.6) power = 7;
////                            }
////                            //while(distance_y < 490){
//////                                pid_y = -pidy.get_pid(distance_y, 500);
//////                                pid_x = -10;
//////                                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 180;
//////                                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
//////                                if(power < 7 && power > 0.6) power = 7;
//////                                omni.omni(angle, power, 0, z, degree);
//////                            }
//////                            while(distance_x < 540){
//////                                pid_y = -pidy.get_pid(distance_y, 500);
//////                                pid_x = pidx.get_pid(distance_x, 550);
//////                                angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI + 180;
//////                                power = sqrt(pow(pid_x,2)+pow(pid_y,2));
//////                                if(power < 7 && power > 0.6) power = 7;
//////                                omni.omni(angle, power, 0, z, degree);
//////                            }
//////                            
////                            subphase = 1;
////                            my_subphase = 0;
////                        } break;
////                        case 1:{
////                            
////                        } break;
////                        default: break;
////                    }
////                }
//                my_phase = 4;
//            } break;
//            case 5:{ // go hanging 4-6
//                angle = 0;
//                if(my_phase == 4){
//                    
//                }
//                my_phase = 5;
//            } break;
//            case 6:{ // go hanging 5-7
//                if(z > 10){
//                    omni.omni(-155, 70, -70, z, (int)z);
//                }
//                else{
//                    degree = 0;
//                    pid_y = pidy.get_pid(distance_y, 20);
//                    pid_x = pidx.get_pid(distance_x, 350);
//                    angle = (float)atan2(pid_x, pid_y)*180/(float)M_PI;
//                    omni.omni(angle, sqrt(pow(pid_x,2)+pow(pid_y,2)), 0, z, degree);
//                }
//                my_phase = 6;
//            } break;
//            case 7:{
//                my_phase = 7;
//            } break;
//            case 8:{
//                my_phase = 8;
//            } break;
//            case 9:{ // roller testing
//                degree = 0;
//                angle = 90;
//                if(-distance_x > 200){
//                    omni.omni(angle, 50, 0, z, degree);
//                }
//            
//                //serial.putc((abs(distance_x-60) & 0x7F) | 0x00);
//                //serial.putc(((abs(distance_x-60) >> 7) & 0x7F) + 0x80);
//
//                //serial.putc((d & 0x7F) | 0x00);
//                //serial.putc(((d >> 7) & 0x7F) | 0x80);
//                my_phase = 9;
//            } break;
//            default :break;
//        }
//        
//        if(sw || button){
//            myled1 = 1;
//            myled2 = !button;
//            myled3 = !sw;
//            phase1_cnt = 0;
//        }
//        else{
//            myled1 = 0;
//            myled2 = 0;
//            myled3 = 0;
//        }
//        
////        d = e.get_counts();
////        oled.OLED_bar(0, 7, (char)d);
////        oled.OLED_line_clear(7, (char)d);
////        sprintf(moji, "x:%5d y:%5d", (int)distance_x, (int)distance_y);
////        oled.OLED_printf(moji, 3);
////        sprintf(moji, "p:%d", phase);
////        oled.OLED_printf(moji, 2);
////        sprintf(moji, "%7.2f", z);
////        oled.OLED_printf(moji, 1);
//    }
//}
//
//float R6093U_get(char data_arr[], char sel) {
//    signed short angle = 0;
//    float ang = 0;
//    
//    switch(sel){
//        case 'X': angle = data_arr[1] | (data_arr[2]<<8); break;
//        case 'Y': angle = data_arr[3] | (data_arr[4]<<8); break;
//        case 'Z': angle = data_arr[5] | (data_arr[6]<<8); break;
//        default : angle = 0; break;
//    }
//    
//    ang = angle * (float)0.01;
//    if((abs(ang)-abs(R6093U_act_before)) > 30){
//        R6093U_act_before = ang;
//        ang = R6093U_before;
//    }
//    else{
//        R6093U_act_before = ang;
//    }
//    R6093U_before = ang;
//    
//    return ang;
//}